# What Do Gesture-Learning Scores Measure? A Three-Round Comparison of Recognition-Contingent Feedback and Visual Instruction

## Aggregate results and reproducibility code

Repository deposit candidate, 24 November 2026. This archive accompanies the IJHCI submission manuscript (Phase 24), not a new experiment. The study contains 46 novice learners (23 per condition), three rounds, 20 hand-configuration targets, 5,520 assessment item observations, 276 recognizer-scored game counts and 138 practice sessions.

### Contents
- `tables/`: 20 CSV files containing the numerical results supporting the main manuscript and supplement. Nineteen are directly regenerated analysis outputs; the remaining table is a descriptive calculation from group means and ceiling counts. An unused hypothetical-bias table from earlier drafts is excluded.
- `analysis/`: model-fitting, sensitivity, descriptive audit and figure-generation code. Script names retain historical identifiers to preserve compatibility. `requirements-tested.txt` records the software versions used in the deposit verification (Python 3.13.5).
- `audit/`: aggregate historical source verification and the new deposit validation. No original participant identifiers or participant-level data rows are included.
- `DATA_DICTIONARY.md`: table definitions, units and statistical interpretation.
- `SHA256SUMS.txt`: checksums for files in this archive.

### Access and ethical restrictions
This package is limited to aggregate data and analysis code. It does not contain the original participant-level exports, interview notes, consent forms, photographs, videos, software screenshots or identifying records. A separate minimized, pseudonymized input package has been prepared for author review and controlled access. Public release of that package requires confirmation of consent, ethics, institutional data policy and disclosure risk. Pseudonymization is not a guarantee of anonymity. The authors should not imply full public access to the underlying individual records if only this aggregate package is deposited. Any controlled-access arrangements must be confirmed by the authors and, where necessary, the journal. Do not choose a data or code license unless the authors have authority to grant it.

### Reproduction
Unzip this archive into a local directory. Install the dependencies with `python -m pip install -r analysis/requirements-tested.txt` (or use `requirements.txt` for compatible versions). To regenerate aggregate plots from the supplied tables, run:

```
python analysis/figures_from_aggregate_tables.py
python analysis/phase21_draw_figure1.py
python analysis/phase21_draw_cross_outcomes.py
```

The participant gain distribution (Supplementary Figure S1) requires authorized participant-level inputs. The interface screenshot figure is not regenerated or distributed here. The model script also creates earlier-style diagnostic figures; the dedicated figure scripts generate the final plotting styles. 

With authorized access to the minimized input CSVs in a local `data/` directory (available separately, not part of this public archive), run the following commands. Use a separate output folder so that frozen result tables are never overwritten:

```
python analysis/reanalysis.py --data-dir data --out-dir recomputed
python analysis/phase21_independence_and_robustness.py --data-dir data --out-dir recomputed --bootstrap 12000
python analysis/independent_source_audit.py --data-dir data --results-dir recomputed/tables --output recomputed/audit/independent_check.json
python analysis/phase23_draw_participant_gain.py --data-dir data
python analysis/check_reproduction.py --results-dir recomputed/tables
```

For faster/stabler linear algebra, set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 before running. Full model refitting cannot be performed with aggregate tables alone. The exact numerical verification used the minimized inputs and reproduced all nineteen model/analysis output tables; the twentieth descriptive table was recomputed from the regenerated means and ceiling counts. The original and minimized input hashes differ by design because identifiers and unused fields were removed. See `audit/deposit_validation.json`.

### Interpretation
All analyses are exploratory. The `llm` label in archived exports identifies the recognition-contingent condition and does not demonstrate live LLM inference. Image-choice accuracy is not independently rated sign-production quality. The game followed the same-round post-assessment. Pooled within-cell associations are descriptive, not evidence of mediation, causation, equivalence or statistical independence. Allocation records and deployed software are unavailable; the two instructional conditions differ in multiple features. The practice-record discrepancies concern recorded exposure, not independently established failures to deliver practice.
