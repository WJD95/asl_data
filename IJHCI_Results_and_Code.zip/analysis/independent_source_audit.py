#!/usr/bin/env python3
"""Independent, privacy-minimizing validation of ASL study exports.

Reads private participant-level CSVs, checks integrity, re-aggregates the public
item-score means independently of reanalysis.py, and verifies public model output.
Writes only group-level, non-identifying numbers and source hashes.

Usage:
 python analysis/independent_source_audit.py \
    --data-dir /private/UserStudy/data \
    --results-dir tables --output audit/phase19_source_audit.json
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import chi2

DATA_FILES = [
 'initial_assessment_data.csv','final_assessment_data.csv',
 'recordings.csv','learning_session_data.csv','whack_a_mole_game.csv',
 'all_users_initial_assessment.csv','all_users_final_assessment.csv',
 'all_users_improvement.csv']

def hash_file(path):
 h = hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''): h.update(block)
 return h.hexdigest()

def allclose_csv(left,right,keycols,tol=5e-5):
 a=pd.read_csv(left);b=pd.read_csv(right)
 if a.shape!=b.shape or set(a)!=set(b):return False,'shape/column mismatch'
 a=a.sort_values(keycols).reset_index(drop=True)
 b=b.sort_values(keycols).reset_index(drop=True)
 for c in a:
  if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c]):
   if not np.allclose(a[c],b[c],atol=tol,rtol=0,equal_nan=True):
    return False,f'numeric mismatch {c}'
  elif not a[c].astype(str).equals(b[c].astype(str)):
   return False,f'categorical mismatch {c}'
 return True,'match'

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--data-dir',type=Path,required=True)
 ap.add_argument('--results-dir',type=Path,default=Path('tables'))
 ap.add_argument('--output',type=Path,default=Path('audit/phase19_source_audit.json'))
 args=ap.parse_args()
 data={n:pd.read_csv(args.data_dir/n) for n in DATA_FILES}
 pre=data['initial_assessment_data.csv']; post=data['final_assessment_data.csv']
 learn=data['learning_session_data.csv']; raw=data['recordings.csv'];game=data['whack_a_mole_game.csv']
 item_cols=[c for c in pre if c.endswith('_correct')]
 assert len(item_cols)==20,'Expected exactly twenty items'
 assert len(pre)==len(post)==len(raw)==len(learn)==138
 assert len(game)==276
 assert len(pre.user_id.unique())==46
 assert len(set(pre.user_id))==len(set(post.user_id))==len(set(raw.user_id))==len(set(learn.user_id))
 for d,cc in [(pre,'Round'),(post,'Round'),(raw,'round'),(learn,'Round')]:
  assert not d.duplicated(['user_id',cc]).any()
  assert set(d[cc])=={1,2,3}
  assert d.groupby('user_id')[cc].nunique().eq(3).all()
  assert d.isna().sum().sum()==0
 for d in (pre,post):
  assert all(d[c].isin([True,False,0,1,'True','False']).all() for c in item_cols)
  for c in [c for c in d if c.endswith('_response_time')]:
   assert np.isfinite(d[c].to_numpy(dtype=float)).all() and (d[c].to_numpy(dtype=float)>0).all()
 assert len(pre.groupby('learning_mode').user_id.unique().loc['llm'])==23
 assert len(pre.groupby('learning_mode').user_id.unique().loc['predefined'])==23
 assert game.groupby(['participant_id','round'])['type'].agg(lambda s:set(s)=={'digit','word'}).all()
 assert game.groupby(['participant_id','round']).size().eq(2).all()
 assert not game.score.isna().any()
 rows=[]
 for group,df in [('Pre',pre),('Post',post)]:
  for _,r in df.iterrows():
   rows.append({'group':r.learning_mode,'round':int(r.Round),'phase':group,
                'count':sum(int(bool(r[x])) for x in item_cols)})
 a=pd.DataFrame(rows)
 assert len(a)==276
 assert a.groupby(['group','round','phase']).size().eq(23).all()
 orig_table=a.groupby(['group','round','phase']).agg(n=('count','size'),mean=('count','mean')).reset_index()
 prev=pd.read_csv(args.results_dir/'assessment_descriptives.csv')
 m=orig_table.merge(prev,on=['group','round','phase'],validate='one_to_one')
 assert len(m)==12 and np.allclose(m.mean_x,m.mean_y,atol=1e-4,rtol=0)
 audit_table=[]
 for file,terms in [('accuracy_GEE_terms.csv','C(group, Sum):C(phase, Sum):C(round, Sum)'),
                    ('latency_GEE_terms.csv','C(group, Sum):C(phase, Sum):C(round, Sum)'),
                    ('games_GEE_terms.csv','C(group, Sum):C(round, Sum)'),
                    ('baseline_adjusted_GEE_terms.csv','C(group, Sum):C(round, Sum)')]:
  d=pd.read_csv(args.results_dir/file)
  r=d.loc[d.term.eq(terms)]
  assert len(r)==1
  v=r.iloc[0]
  p=float(chi2.sf(v.chi2,v.df))
  assert abs(p-v.p)<5e-7  # published CSV values are rounded
  audit_table.append({'model_file':file,'term':terms,'chi2':round(float(v.chi2),6),
                      'df':int(v.df),'p':round(p,9),'chi2_p_check':'PASS'})
 c=pd.read_csv(args.results_dir/'marginal_effect_contrasts.csv')
 assert len(c)==3
 assert ((c.low_pp<=0)&(c.high_pp>=0)).all()
 for _,r in c.iterrows():
  se=(r.high_pp-r.low_pp)/(2*1.96)
  assert abs((r.estimate_pp-r.low_pp)-(r.high_pp-r.estimate_pp))<1e-4
  from scipy.stats import norm
  assert abs(r.p-2*norm.sf(abs(r.estimate_pp/se)))<1e-6
 # Inspect the nested and flat session exports, without retaining participant IDs.
 diff,zero_pos,plus_10,incomplete=0,0,0,0
 for _,rec in raw.iterrows():
  nested=json.loads(rec.learning_session)
  order=set(str(x) for x in json.loads(rec.learning_order))
  if rec.learning_mode=='predefined' and int(rec['round'])==1 and len(order)<20: incomplete+=1
  flat=learn[(learn.user_id==rec.user_id)&(learn.Round==rec['round'])]
  assert len(flat)==1
  flat=flat.iloc[0]
  for k,v in nested.items():
   x=float(v['time']);y=float(flat['item_'+str(k)+'_time'])
   if abs(x-y)>0.0051:
    diff+=1;zero_pos+=int(x==0 and y>0);plus_10+=int(abs(y-x-10)<0.0051)
 assert diff==48 and zero_pos==27 and plus_10==21 and incomplete==9
 result={'audit_version':'phase19-independent-1','source_level':'supplied participant-level analysis inputs',
         'records':{'n_participants':46,'n_per_condition':23,'n_rounds':3,'n_targets':20,
                    'n_item_responses':5520,'n_game_observations':276,
                    'n_practice_sessions':138,'n_missing_item_or_game_records':0},
         'recomputed_descriptive_means':'PASS (all twelve group-round-phase means)',
         'model_wald_crosschecks':audit_table,'model_contrast_ci_check':'PASS (3/3 span zero)',
         'session_integrity':{'incomplete_first_round_predefined_sessions':incomplete,
                              'nested_to_flat_duration_discrepancies':diff,
                              'nested_zero_to_flat_positive':zero_pos,
                              'flat_exceeds_nested_by_10_seconds':plus_10},
         'source_sha256':{n:hash_file(args.data_dir/n) for n in DATA_FILES},
         'privacy_note':'No individual IDs, signed forms or participant rows exported.'}
 args.output.parent.mkdir(parents=True,exist_ok=True)
 args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 print('PASS: original-level integrity and model-output audit (46 individuals, 5,520 item responses; 4 Wald tests, 12 means, 3 CIs, log checks)')

if __name__=='__main__':main()
