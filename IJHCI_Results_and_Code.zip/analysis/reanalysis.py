#!/usr/bin/env python3
"""Reproduce revised IJHCI aggregates and vector figures from the private UserStudy data.

This script intentionally exports no participant identifiers, individual raw rows or narrative text.
Run in the project folder:
 python analysis/reanalysis.py --data-dir /path/to/private/UserStudy/data --out-dir .
Data arrays are built locally; all published uncertainty intervals are calculated from source records.
"""
import argparse, json, math
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from scipy import stats
from scipy.special import expit
import statsmodels.api as sm
import statsmodels.formula.api as smf
from patsy import build_design_matrices

PAL={'mist':'#DDE6F3','blue':'#7FA4C8','lilac':'#B59BC8','pink':'#D08AB6',
     'mint':'#8FB79B','violet':'#6A5A8F','plum':'#3F345B','ink':'#242032','gray':'#77717D',
     'grid':'#E8E8EC'}
COL={'llm':PAL['blue'],'predefined':PAL['pink']}
MARK={'llm':'o','predefined':'s'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.5,'axes.titlesize':11,'axes.labelsize':9.5,
                     'xtick.labelsize':8.4,'ytick.labelsize':8.4,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.edgecolor':PAL['gray'],'axes.labelcolor':PAL['ink'],
                     'text.color':PAL['ink'],'xtick.color':PAL['ink'],'ytick.color':PAL['ink'],
                     'savefig.facecolor':'white','figure.facecolor':'white','pdf.fonttype':42,
                     'legend.frameon':False})

def ci95(values):
    x=np.asarray(values,dtype=float)
    n=len(x); m=x.mean(); sd=x.std(ddof=1)
    e=stats.t.ppf(.975,n-1)*sd/np.sqrt(n)
    return float(m),float(m-e),float(m+e)

def tidy(model,name):
    t=model.wald_test_terms().table
    rows=[]
    for term,row in t.iterrows():
        rows.append(dict(model=name,term=term,chi2=float(np.asarray(row['statistic']).ravel()[0]),
                         df=int(row['df_constraint']),p=float(row['pvalue'])))
    return pd.DataFrame(rows)

def outfig(fig,output,name):
    fig.savefig(output/'figures'/(name+'.pdf'),bbox_inches='tight',pad_inches=.08)
    fig.savefig(output/'figures'/(name+'.png'),bbox_inches='tight',pad_inches=.08,dpi=420)
    plt.close(fig)

def soften(ax,axis='x'):
    ax.grid(which='major',axis=axis,color=PAL['grid'],linewidth=.7)
    ax.set_axisbelow(True)

def sample_mean_by_group(df,var,keys):
    out=[]
    for gg,sub in df.groupby(keys,observed=True):
        if not isinstance(gg,tuple):gg=(gg,)
        mean,lo,hi=ci95(sub[var]); out.append(dict(zip(keys,gg))|dict(n=len(sub),mean=mean,lo=lo,hi=hi))
    return pd.DataFrame(out)

def main():
    pa=argparse.ArgumentParser(); pa.add_argument('--data-dir',required=True); pa.add_argument('--out-dir',default='.')
    args=pa.parse_args()
    D=Path(args.data_dir); O=Path(args.out_dir)
    for sub in ['figures','tables','audit']:(O/sub).mkdir(parents=True,exist_ok=True)
    pre=pd.read_csv(D/'initial_assessment_data.csv'); post=pd.read_csv(D/'final_assessment_data.csv')
    rec=pd.read_csv(D/'recordings.csv'); learn=pd.read_csv(D/'learning_session_data.csv')
    game=pd.read_csv(D/'whack_a_mole_game.csv'); prior=pd.read_csv(D/'all_users_initial_assessment.csv')
    priorpost=pd.read_csv(D/'all_users_final_assessment.csv'); priorgain=pd.read_csv(D/'all_users_improvement.csv')
    items=[c[:-8] for c in pre.columns if c.endswith('_correct')]; assert len(items)==20
    rows=[]
    for phase,df in [('Pre',pre),('Post',post)]:
        for _,r in df.iterrows():
            for item in items:
                rows.append({'participant':str(r['user_id']),'group':str(r['learning_mode']),
                             'round':int(r['Round']),'phase':phase,'item':item,
                             'category':'digits' if item in ['item_'+str(i) for i in range(10)] else 'words',
                             'correct':int(bool(r[item+'_correct'])),
                             'response_time':float(r[item+'_response_time'])})
    A=pd.DataFrame(rows)
    assert len(A)==5520 and A.participant.nunique()==46
    assert A.groupby(['participant','round','phase']).size().eq(20).all()
    for var,cat in [('group',['predefined','llm']),('phase',['Pre','Post']),('round',[1,2,3]),('item',items)]:
        A[var]=pd.Categorical(A[var],categories=cat)
    A['log_response_time']=np.log(A['response_time'])
    form='correct ~ C(group, Sum)*C(phase, Sum)*C(round, Sum) + C(item)'
    model=smf.gee(form,groups='participant',data=A,family=sm.families.Binomial(),
                  cov_struct=sm.cov_struct.Exchangeable()).fit()
    model_terms=tidy(model,'accuracy item binomial GEE')
    modelrt=smf.gee('log_response_time ~ C(group, Sum)*C(phase, Sum)*C(round, Sum) + C(item)',
        groups='participant',data=A,family=sm.families.Gaussian(),
        cov_struct=sm.cov_struct.Exchangeable()).fit()
    modelrt_terms=tidy(modelrt,'assessment RT log-Gaussian GEE')
    # Cross-check score aggregation with nested summary columns, no individually identifying outputs.
    scores=A.groupby(['participant','group','round','phase'],observed=True).agg(
        correct=('correct','sum'),latency=('response_time','mean')).reset_index()
    gain=scores.pivot(index=['participant','group','round'],columns='phase',values='correct').reset_index()
    gain['change']=gain['Post']-gain['Pre']
    # Exploratory post-score ANCOVA-style sensitivity at participant-round level.
    # It adjusts the 0--20 post-assessment count for that round's pre-assessment count.
    # This is not an independent trial or an estimate of the LLM-specific effect.
    baseline_gee=smf.gee(
        'Post ~ Pre + C(group, Sum)*C(round, Sum)', groups='participant',
        data=gain, family=sm.families.Gaussian(),
        cov_struct=sm.cov_struct.Exchangeable()).fit()
    baseline_terms=tidy(baseline_gee,'baseline-adjusted post-score Gaussian GEE')
    baseline_coeff=pd.DataFrame({
        'term':baseline_gee.params.index,
        'estimate':baseline_gee.params.values,
        'robust_se':baseline_gee.bse.values,
        'lower_95':baseline_gee.params.values-1.96*baseline_gee.bse.values,
        'upper_95':baseline_gee.params.values+1.96*baseline_gee.bse.values,
        'p':baseline_gee.pvalues.values})
    ceiling_summary=scores.groupby(['group','round','phase'],observed=True).agg(
        n_participants=('correct','size'),mean_correct=('correct','mean'),
        n_at_20=('correct',lambda x:int((x==20).sum())),
        n_at_least_18=('correct',lambda x:int((x>=18).sum())),
        n_at_least_16=('correct',lambda x:int((x>=16).sum()))).reset_index()
    gain_desc=sample_mean_by_group(gain,'change',['group','round'])
    scr_desc=sample_mean_by_group(scores,'correct',['group','round','phase'])
    scr_desc['accuracy_pct']=scr_desc['mean']*5
    # Reconstruct model-standardized accuracy risk differences with delta-method SEs.
    # Direct standardization averages over the 20 observed target items with equal weights.
    model_treat=smf.gee("correct ~ C(group, Treatment(reference='predefined'))*C(phase, Treatment(reference='Pre'))*C(round, Treatment(reference=1)) + C(item)",
        groups='participant',data=A,family=sm.families.Binomial(),
        cov_struct=sm.cov_struct.Exchangeable()).fit()
    beta=np.asarray(model_treat.params); cov=np.asarray(model_treat.cov_params())
    design=model_treat.model.data.design_info
    cells={}
    for g in ['predefined','llm']:
        for ph in ['Pre','Post']:
            for rd in [1,2,3]:
                z=pd.DataFrame({'group':[g]*20,'phase':[ph]*20,'round':[rd]*20,'item':items})
                for col,cat in [('group',['predefined','llm']),('phase',['Pre','Post']),('round',[1,2,3]),('item',items)]:
                    z[col]=pd.Categorical(z[col],categories=cat)
                X=np.asarray(build_design_matrices([design],z)[0])
                prob=expit(X@beta)
                cells[(g,ph,rd)]=(float(prob.mean()),((prob*(1-prob))[:,None]*X).mean(axis=0))
    contrasts=[]
    for rd in [1,2,3]:
        c={('llm','Post',rd):1,('llm','Pre',rd):-1,('predefined','Post',rd):-1,('predefined','Pre',rd):1}
        est=sum(w*cells[k][0] for k,w in c.items()); grad=sum((w*cells[k][1] for k,w in c.items()),np.zeros_like(beta))
        se=float(np.sqrt(grad@cov@grad)); lo,hi=est-1.96*se,est+1.96*se
        contrasts.append(dict(round=rd,estimate_pp=100*est,low_pp=100*lo,high_pp=100*hi,
                              p=2*stats.norm.sf(abs(est/se))))
    contrasts=pd.DataFrame(contrasts)
    # Participant-level 20,000 bootstrap for change in group gap between rounds 3 and 1.
    gm=gain.pivot(index='participant',columns='round',values='change').sort_index()
    grp=gain.drop_duplicates('participant').set_index('participant')['group'].astype(str).reindex(gm.index)
    mask=(grp.values=='llm'); mat=gm[[1,2,3]].values
    diff=mat[mask].mean(axis=0)-mat[~mask].mean(axis=0); observed=float(diff[2]-diff[0])
    rng=np.random.default_rng(20261117); B=20000
    bootstrap=np.empty(B)
    for b in range(B):
        aa=mat[mask][rng.integers(0,mask.sum(),mask.sum())]
        cc=mat[~mask][rng.integers(0,(~mask).sum(),(~mask).sum())]
        bootstrap[b]=(aa[:,2]-aa[:,0]).mean()-(cc[:,2]-cc[:,0]).mean()
    bootlo,boothi=np.quantile(bootstrap,[.025,.975]); perm=np.empty(B)
    for b in range(B):
        lab=rng.permutation(mask)
        perm[b]=(mat[lab,2]-mat[lab,0]).mean()-(mat[~lab,2]-mat[~lab,0]).mean()
    permp=(1+(np.abs(perm)>=abs(observed)).sum())/(B+1)
    bootstrap_info=pd.DataFrame([dict(est_items=observed,low=bootlo,high=boothi,perm_p=permp,B=B)])
    # Cohort overlap check; old n=20 exactly matches full archive Round-1 assessments.
    priorids=set(prior.user_id.astype(str)); fullids=set(pre.user_id.astype(str)); matches=priorids&fullids
    count_prior_correct_pre=count_prior_correct_post=count_prior_time_pre=count_prior_time_post=0
    for hist,now,phase in [(prior,pre,'pre'),(priorpost,post,'post')]:
        now=now[now.Round==1].set_index('user_id')
        for _,r in hist.iterrows():
            u=str(r.user_id); nr=now.loc[u]
            for item in items:
                name=item[5:]
                cm=int(bool(r['item_'+name])==bool(nr[item+'_correct']))
                tm=int(abs(float(r['response_'+name])-float(nr[item+'_response_time']))<1e-8)
                if phase=='pre':count_prior_correct_pre+=cm;count_prior_time_pre+=tm
                else:count_prior_correct_post+=cm;count_prior_time_post+=tm
    # Event log extraction / discrepancy audit
    practice=[]; session=[]; discrepancy=[]
    for _,r in rec.iterrows():
        js=json.loads(r.learning_session); order=json.loads(r.learning_order)
        positive={str(k) for k,v in js.items() if float(v['time'])>0}
        distinct={str(x) for x in order}
        session.append({'participant':str(r.user_id),'group':str(r.learning_mode),'round':int(r['round']),
                        'n_events':len(order),'n_unique':len(distinct),'complete20':int(len(distinct)==20),
                        'event_time_consistent':int(positive==distinct)})
        for key,val in js.items():
            secs=float(val['time'])
            if secs>0:
                practice.append({'participant':str(r.user_id),'group':str(r.learning_mode),
                                 'round':int(r['round']),'item':'item_'+str(key),'seconds':secs})
            lrow=learn[(learn.user_id==r.user_id)&(learn.Round==r['round'])].iloc[0]
            flat=float(lrow['item_'+str(key)+'_time'])
            if abs(flat-secs)>.0051:
                discrepancy.append((str(r.learning_mode),int(r['round']),str(key),secs,flat))
    S=pd.DataFrame(session); P=pd.DataFrame(practice)
    P['group']=pd.Categorical(P.group,categories=['predefined','llm'])
    P['round']=pd.Categorical(P['round'],categories=[1,2,3])
    practice_part=P.groupby(['participant','group','round'],observed=True).seconds.mean().reset_index()
    practice_part['log_mean']=np.log(practice_part.seconds)
    practice_model=smf.gee('log_mean ~ C(group, Sum)*C(round, Sum)',groups='participant',
        data=practice_part,family=sm.families.Gaussian(),cov_struct=sm.cov_struct.Exchangeable()).fit()
    practice_desc=sample_mean_by_group(practice_part,'seconds',['group','round'])
    S['cohort']=np.where(S.participant.isin(priorids),'Earlier 20','Additional 26')
    coverage=S.groupby(['cohort','group','round'],observed=True).agg(n=('complete20','size'),
        events_mean=('n_events','mean'),targets_mean=('n_unique','mean'),n_complete=('complete20','sum')).reset_index()
    # Games
    GG=game.merge(pre[['user_id','learning_mode']].drop_duplicates(),left_on='participant_id',right_on='user_id')
    GG['group']=pd.Categorical(GG.learning_mode,categories=['predefined','llm'])
    GG['round']=pd.Categorical(GG['round'],categories=[1,2,3]);GG['type']=pd.Categorical(GG.type,categories=['digit','word'])
    games_model=smf.gee('score ~ C(group, Sum)*C(round, Sum)*C(type, Sum)',
       groups='participant_id',data=GG,family=sm.families.Poisson(),
       cov_struct=sm.cov_struct.Exchangeable()).fit()
    games_desc=sample_mean_by_group(GG,'score',['group','round','type'])
    # Participant RT grouped, CI based on n=23 independent clusters per group.
    rt_desc=sample_mean_by_group(scores,'latency',['group','round','phase'])
    # Sample sensitivity
    sensitivity=[]
    for label,keep in [('Full 46',fullids),('Additional 26',fullids-priorids),('Earlier 20',matches)]:
        sub=A[A.participant.isin(keep)]
        mm=smf.gee(form,groups='participant',data=sub,family=sm.families.Binomial(),cov_struct=sm.cov_struct.Exchangeable()).fit()
        t=tidy(mm,label)
        row=t[t.term.str.contains('group')&t.term.str.contains('phase')&t.term.str.contains('round')].iloc[0]
        sensitivity.append(dict(subset=label,n=len(keep),chi2=row.chi2,df=row.df,p=row.p))
    # Exclude 9 incomplete R1 predefined participants as sensitivity, not confirmatory
    abnormal=set(S[(S.group=='predefined')&(S['round']==1)&(S.n_unique<20)].participant)
    sub=A[~A.participant.isin(abnormal)];mm=smf.gee(form,groups='participant',data=sub,
      family=sm.families.Binomial(),cov_struct=sm.cov_struct.Exchangeable()).fit()
    t=tidy(mm,'Exclude nine incomplete');row=t[t.term.str.contains('group')&t.term.str.contains('phase')&t.term.str.contains('round')].iloc[0]
    sensitivity.append(dict(subset='Exclude 9 incomplete',n=37,chi2=row.chi2,df=row.df,p=row.p))
    sensitivity=pd.DataFrame(sensitivity)
    # Save models, aggregated data, auditing checks. No participant-level user identifiers in output.
    for name,df in [('assessment_descriptives',scr_desc),('gain_descriptives',gain_desc),
                    ('marginal_effect_contrasts',contrasts),('bootstrap_gain_change',bootstrap_info),
                    ('accuracy_GEE_terms',model_terms),('latency_GEE_terms',modelrt_terms),
                    ('latency_descriptives',rt_desc),('practice_descriptives',practice_desc),
                    ('practice_GEE_terms',tidy(practice_model,'practice target duration')),
                    ('practice_coverage',coverage),('games_descriptives',games_desc),
                    ('games_GEE_terms',tidy(games_model,'game count Poisson')),
                    ('subgroup_sensitivity',sensitivity),
                    ('baseline_adjusted_GEE_terms',baseline_terms),
                    ('baseline_adjusted_GEE_coefficients',baseline_coeff),
                    ('ceiling_summary',ceiling_summary)]:
        df.to_csv(O/'tables'/(name+'.csv'),index=False,float_format='%.7g')
    audit={'N':46,'N_rows_assessment':len(A),'n_prior_ids':len(matches),
           'match_pre_correct':count_prior_correct_pre,'match_post_correct':count_prior_correct_post,
           'match_pre_rt':count_prior_time_pre,'match_post_rt':count_prior_time_post,
           'n_log_discrepancies':len(discrepancy),'rawzero_flatpos':sum(v==0 and f>0 for _,_,_,v,f in discrepancy),
           'flat_delta_10':sum(abs(f-v-10)<.0051 for _,_,_,v,f in discrepancy),
           'n_incomplete_controls':len(abnormal),'all_order_set_matches':int(S.event_time_consistent.sum()),
           'primary_wald_p':float(model_terms[model_terms.term.str.contains('group.*phase.*round',regex=True)].p.iloc[0])}
    base_inter=baseline_terms[baseline_terms.term.str.contains('group') & baseline_terms.term.str.contains('round')].iloc[0]
    audit['baseline_adjusted_condition_by_round_chi2']=float(base_inter.chi2)
    audit['baseline_adjusted_condition_by_round_p']=float(base_inter.p)
    (O/'audit'/'integrity_checks.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    # Figure 1 is a privacy-preserving, archival-source schematic created independently
    # by analysis/figure_measurement_map.py. Historical UI screenshots are intentionally
    # not packaged or regenerated as publication figures without rights verification.
    # FIGURE B: Multi-panel faceted horizontal dumbbell for assessment pre/post, original values, 95% CI per cell.
    fig,axes=plt.subplots(1,3,figsize=(11.4,3.2),sharex=True,sharey=True)
    for j,rd in enumerate([1,2,3]):
        ax=axes[j]
        for k,g in enumerate(['llm','predefined']):
            yy=1-k
            dat={}
            for ph in ['Pre','Post']:
                x=scores[(scores.group==g)&(scores['round']==rd)&(scores.phase==ph)].correct.values*5
                m,lo,hi=ci95(x);dat[ph]=(m,lo,hi)
            ax.plot([dat['Pre'][0],dat['Post'][0]],[yy,yy],color=PAL['lilac'],linewidth=3.2,zorder=1,alpha=.8)
            for ph in ['Pre','Post']:
                m,lo,hi=dat[ph]
                color=PAL['blue'] if ph=='Pre' else (PAL['violet'] if g=='llm' else PAL['pink'])
                marker='o' if ph=='Pre' else 'D'
                ax.plot([lo,hi],[yy,yy],color=color,linewidth=1.5,zorder=3)
                ax.plot([lo,lo],[yy-.08,yy+.08],color=color,linewidth=1,zorder=3)
                ax.plot([hi,hi],[yy-.08,yy+.08],color=color,linewidth=1,zorder=3)
                ax.scatter(m,yy,marker=marker,color=color,s=58,edgecolors='white',linewidth=.7,zorder=5)
            # difference text away from data points
            ax.text(31,yy+.2,f"+{(dat['Post'][0]-dat['Pre'][0]):.1f} pp",fontsize=8,color=PAL['plum'],weight='bold')
        ax.set_title('Round '+str(rd),pad=12,color=PAL['plum'],weight='bold')
        ax.set_xlim(20,101);ax.set_xticks([25,50,75,100]);ax.set_ylim(-.5,1.5)
        soften(ax);ax.spines['left'].set_visible(False)
    axes[0].set_yticks([1,0],['Recognition\nfeedback','Predefined\ninstruction'])
    for ax in axes[1:]:ax.tick_params(axis='y',which='both',left=False,labelleft=False)
    fig.supxlabel('Image-selection accuracy (%)     ● Pre-assessment     ◆ Post-assessment',fontsize=9.2,y=.04)
    fig.subplots_adjust(left=.135,right=.99,top=.85,bottom=.25,wspace=.10)
    outfig(fig,O,'Fig2_accuracy_dumbbells')
    # FIGURE C: model-based between-condition within-round gain difference in pp, 95% robust covariance CI.
    fig,ax=plt.subplots(figsize=(7.4,3.8))
    col=PAL['violet']; yy=[2,1,0]
    for y,(_,r) in zip(yy,contrasts.iterrows()):
        ax.plot([r.low_pp,r.high_pp],[y,y],color=col,linewidth=2.5,zorder=2)
        ax.plot([r.low_pp,r.low_pp],[y-.08,y+.08],color=col,zorder=2)
        ax.plot([r.high_pp,r.high_pp],[y-.08,y+.08],color=col,zorder=2)
        ax.scatter(r.estimate_pp,y,color=PAL['pink'],s=80,edgecolor='white',linewidth=.9,zorder=3,marker='D')
        ax.text(13.2,y,f"{r.estimate_pp:+.1f} pp   [{r.low_pp:+.1f}, {r.high_pp:+.1f}]",
                va='center',fontsize=8.3,color=PAL['plum'])
    ax.axvline(0,color=PAL['gray'],lw=1.1,linestyle='--')
    ax.set_xlim(-16,35);ax.set_ylim(-.55,2.55)
    ax.set_yticks(yy,['Round 1','Round 2','Round 3']); ax.set_xticks([-15,-10,-5,0,5,10,15])
    ax.set_xlabel('Difference in within-round gain (recognition - predefined), percentage points')
    ax.set_title('Adjusted contrasts of assessment improvement',loc='left',weight='bold',color=PAL['plum'],pad=9)
    soften(ax)
    fig.text(.12,.045,'Model-standardised means; participant-clustered robust 95% CIs. No per-round contrast excludes zero.',fontsize=8,color=PAL['gray'])
    fig.subplots_adjust(left=.16,right=.985,top=.85,bottom=.23)
    outfig(fig,O,'Fig3_model_contrasts_forest')
    # FIGURE D: individual gain distributions + mean uncertainty (private IDs omitted).
    fig,ax=plt.subplots(figsize=(8,4.0))
    rng=np.random.default_rng(20261117)
    for k,g in enumerate(['llm','predefined']):
        color=COL[g]
        for j,rd in enumerate([1,2,3]):
            vals=gain[(gain.group==g)&(gain['round']==rd)].change.to_numpy()
            pos=j+1+(-.18 if g=='llm' else .18)
            jitter=rng.uniform(-.065,.065,len(vals))
            ax.scatter(pos+jitter,vals,s=24,color=color,alpha=.38,lw=.2,edgecolor=PAL['plum'],zorder=1)
            m,lo,hi=ci95(vals)
            ax.plot([pos,pos],[lo,hi],color=PAL['plum'],lw=2.1,zorder=4)
            ax.scatter(pos,m,s=74,marker='D',color=color,edgecolor=PAL['plum'],linewidth=.8,zorder=5)
    ax.axhline(0,color=PAL['gray'],lw=.85,linestyle='--')
    ax.set_xticks([1,2,3],['Round 1','Round 2','Round 3']);ax.set_ylim(-4,13)
    ax.set_ylabel('Within-round score change (out of 20)')
    ax.set_title('Participant-level score changes (n = 23 per condition)',loc='left',weight='bold',color=PAL['plum'])
    soften(ax,axis='y')
    ax.scatter([],[],marker='o',color=PAL['blue'],label='Recognition feedback')
    ax.scatter([],[],marker='s',color=PAL['pink'],label='Predefined instruction')
    ax.legend(loc='upper right',ncol=2,fontsize=8.2)
    fig.subplots_adjust(left=.12,right=.97,top=.86,bottom=.16)
    outfig(fig,O,'Fig4_participant_gain_distribution')
    # FIGURE E: assessment response time, grouped dots with CI (no lines imply continuous trajectory).
    fig,ax=plt.subplots(figsize=(8.1,4.2))
    offsets={('llm','Pre'):-.27,('llm','Post'):-.09,('predefined','Pre'):.09,('predefined','Post'):.27}
    colors={('llm','Pre'):PAL['blue'],('llm','Post'):PAL['violet'],('predefined','Pre'):PAL['pink'],('predefined','Post'):PAL['mint']}
    for (g,ph),off in offsets.items():
        for rd in [1,2,3]:
            v=scores[(scores.group==g)&(scores.phase==ph)&(scores['round']==rd)].latency.values
            m,lo,hi=ci95(v);x=rd+off
            ax.plot([x,x],[lo,hi],color=colors[(g,ph)],lw=1.7)
            ax.plot([x-.028,x+.028],[lo,lo],color=colors[(g,ph)],lw=1)
            ax.plot([x-.028,x+.028],[hi,hi],color=colors[(g,ph)],lw=1)
            ax.scatter(x,m,s=60,marker=('o' if ph=='Pre' else 'D'),color=colors[(g,ph)],
                edgecolor=PAL['plum'],linewidth=.5,zorder=4)
    ax.set_xlim(.5,3.52);ax.set_xticks([1,2,3],['Round 1','Round 2','Round 3'])
    ax.set_ylabel('Participant-mean assessment latency (seconds)')
    ax.set_title('Assessment response times (not sign-production latency)',loc='left',weight='bold',color=PAL['plum'])
    soften(ax,axis='y')
    for key,label in [(('llm','Pre'),'Feedback / pre'),(('llm','Post'),'Feedback / post'),
                      (('predefined','Pre'),'Predefined / pre'),(('predefined','Post'),'Predefined / post')]:
        ax.scatter([],[],s=36,marker=('o' if key[1]=='Pre' else 'D'),color=colors[key],label=label)
    ax.legend(loc='upper right',ncol=2,fontsize=8.5)
    fig.subplots_adjust(left=.12,right=.98,top=.86,bottom=.15)
    outfig(fig,O,'Fig5_response_time_dotwhisker')
    # FIGURE F: practice coverage, clear small multiples events vs unique target counts.
    round1=S[S['round']==1].copy(); cats=[('Additional 26','llm'),('Additional 26','predefined'),('Earlier 20','llm'),('Earlier 20','predefined')]
    fig,axes=plt.subplots(1,2,figsize=(10.6,3.7),sharey=True)
    for ax,metric,title in [(axes[0],'n_events','Recorded sequence events'),(axes[1],'n_unique','Distinct target labels')]:
        for i,(coh,g) in enumerate(cats):
            ss=round1[(round1.cohort==coh)&(round1.group==g)][metric].to_numpy()
            m,lo,hi=ci95(ss)
            ax.scatter([i+1]*len(ss),ss,s=18,color=COL[g],alpha=.36,zorder=2,edgecolors=PAL['plum'],linewidth=.3)
            ax.plot([i+1,i+1],[lo,hi],color=PAL['plum'],lw=2.4,zorder=3)
            ax.scatter(i+1,m,color=COL[g],marker='D',s=75,edgecolors=PAL['plum'],linewidth=.8,zorder=5)
        ax.axhline(20,color=PAL['gray'],ls='--',lw=1)
        ax.set_xticks([1,2,3,4],['New 26\nfeedback','New 26\npredefined','Prior 20\nfeedback','Prior 20\npredefined'])
        ax.set_xlim(.5,4.55);ax.set_title(title,color=PAL['plum'],weight='bold')
        ax.set_ylim(12,48);soften(ax,axis='y')
    axes[0].set_ylabel('Count per participant, Round 1')
    fig.suptitle('First-round practice exposure differs in the early predefined cohort',x=.10,ha='left',weight='bold',color=PAL['plum'])
    fig.subplots_adjust(left=.08,right=.98,top=.81,bottom=.25,wspace=.13)
    outfig(fig,O,'Fig6_practice_coverage')
    # FIGURE G: game response counts by category, grouped dots and 95%CI
    fig,axes=plt.subplots(1,2,figsize=(9.2,3.8),sharey=True)
    for ax,ty in zip(axes,['digit','word']):
        for g,off in [('llm',-.15),('predefined',.15)]:
            for rd in [1,2,3]:
                ss=GG[(GG.group==g)&(GG['round']==rd)&(GG.type==ty)].score.values
                m,lo,hi=ci95(ss);x=rd+off
                ax.plot([x,x],[lo,hi],color=COL[g],lw=2)
                ax.scatter(x,m,marker=MARK[g],color=COL[g],s=70,edgecolor=PAL['plum'],linewidth=.5,zorder=4)
        ax.set_title('Digit-labelled game' if ty=='digit' else 'Word-labelled game',color=PAL['plum'],weight='bold')
        ax.set_xticks([1,2,3],['R1','R2','R3']);soften(ax,axis='y')
    axes[0].set_ylabel('Recognizer-accepted count')
    fig.suptitle('Reinforcement scores: model-dependent outcomes',x=.09,ha='left',weight='bold',color=PAL['plum'])
    fig.legend(handles=[plt.Line2D([0],[0],color=PAL['blue'],marker='o',ls='',label='Recognition feedback'),
                        plt.Line2D([0],[0],color=PAL['pink'],marker='s',ls='',label='Predefined instruction')],
               loc='lower center',ncol=2,bbox_to_anchor=(.5,-.01),frameon=False,fontsize=8.7)
    fig.subplots_adjust(left=.09,right=.98,top=.77,bottom=.21,wspace=.13)
    outfig(fig,O,'Fig7_games_dotwhisker')
    print('MAIN_GEE',model_terms.loc[model_terms.term.str.contains('group.*phase.*round',regex=True)].to_dict('records'))
    print('RT_GEE',modelrt_terms.loc[modelrt_terms.term.str.contains('group.*phase.*round',regex=True)].to_dict('records'))
    print('BOOTSTRAP',bootstrap_info.to_dict('records'))
    print('CONTRASTS',contrasts.to_dict('records'))
    print('SENSITIVITY',sensitivity.to_dict('records'))
    print('AUDIT',audit)
    print('GAMES',tidy(games_model,'game count GEE')[lambda x:x.term.str.contains('group.*round',regex=True)].to_dict('records'))

if __name__=='__main__':main()
