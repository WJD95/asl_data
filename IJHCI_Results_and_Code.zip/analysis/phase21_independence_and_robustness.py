#!/usr/bin/env python3
"""Exploratory cross-outcome associations and GEE stability checks, using private original exports.
No participant-level records or IDs are written to project tables or audit files.
Run: OPENBLAS_NUM_THREADS=1 python analysis/phase21_independence_and_robustness.py --data-dir PRIVATE_DIR --out-dir .
"""
import argparse,hashlib,json,warnings
from pathlib import Path
import numpy as np,pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import chi2

def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def within_r(x,y):
 return float((x*y).sum()/np.sqrt((x*x).sum()*(y*y).sum()))

def centered_corr(groups, x, y):
 # Inputs: 2 group arrays (n=23, rounds=3). Demean each group x round,
 # then pool the six equal-sized cells. Retain all three rounds per sampled participant.
 xx=np.concatenate([a-a.mean(axis=0,keepdims=True) for a in x]).ravel()
 yy=np.concatenate([a-a.mean(axis=0,keepdims=True) for a in y]).ravel()
 return within_r(xx,yy)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--data-dir',required=True,type=Path);ap.add_argument('--out-dir',default='.',type=Path);ap.add_argument('--bootstrap',type=int,default=10000);args=ap.parse_args()
 D=args.data_dir;O=args.out_dir; (O/'tables').mkdir(exist_ok=True,parents=True);(O/'audit').mkdir(exist_ok=True,parents=True)
 pre=pd.read_csv(D/'initial_assessment_data.csv');post=pd.read_csv(D/'final_assessment_data.csv');game=pd.read_csv(D/'whack_a_mole_game.csv')
 cols=[c for c in pre if c.endswith('_correct')];items=[c[:-8] for c in cols];assert len(items)==20
 def scores(df,column):
  z=df[['user_id','learning_mode','Round']].copy();z.columns=['participant','group','round'];z[column]=df[cols].astype(int).sum(axis=1).values;return z
 s=scores(pre,'pre').merge(scores(post,'post'),on=['participant','group','round'],validate='one_to_one');s['gain']=s['post']-s['pre']
 G=game.pivot_table(index=['participant_id','round'],columns='type',values='score',aggfunc='sum').reset_index()
 G['game_total']=G['digit']+G['word'];s=s.merge(G[['participant_id','round','game_total']],left_on=['participant','round'],right_on=['participant_id','round'],validate='one_to_one').drop(columns='participant_id')
 assert len(s)==138 and s.participant.nunique()==46 and s.groupby(['group','round']).size().eq(23).all()
 groups=['llm','predefined'];arrays={}
 for gr in groups:
  sub=s[s.group==gr]
  mats={}
  for variable in ['game_total','pre','post','gain']:
   mats[variable]=sub.pivot(index='participant',columns='round',values=variable)[[1,2,3]].sort_index().values.astype(float)
   assert mats[variable].shape==(23,3)
  arrays[gr]=mats
 rng=np.random.default_rng(20261123);B=args.bootstrap
 res=[]; evidence={}
 for y in ['post','gain']:
  X=[arrays[g]['game_total'] for g in groups];Y=[arrays[g][y] for g in groups]
  pooledx=np.concatenate(X).ravel(); pooledy=np.concatenate(Y).ravel()
  raw_r=float(np.corrcoef(pooledx,pooledy)[0,1]); adj_r=centered_corr(groups,X,Y)
  br=np.empty(B);ba=np.empty(B)
  for i in range(B):
   sampled=[rng.integers(0,23,23) for _ in groups]
   xboot=[a[j] for a,j in zip(X,sampled)];yboot=[a[j] for a,j in zip(Y,sampled)]
   br[i]=np.corrcoef(np.concatenate(xboot).ravel(),np.concatenate(yboot).ravel())[0,1]
   ba[i]=centered_corr(groups,xboot,yboot)
  for t,r,b in [('pooled_ignoring_group_round',raw_r,br),('within_condition_round',adj_r,ba)]:
   low,high=np.quantile(b,[0.025,0.975]); res.append({'game_count_vs':y,'analysis':t,'n_participants':46,'n_participant_rounds':138,'pearson_r':r,'cluster_bootstrap_low':low,'cluster_bootstrap_high':high,'bootstrap_replicates':B})
  evidence[y]={'raw':raw_r,'centered':adj_r,'centered_ci':[float(np.quantile(ba,.025)),float(np.quantile(ba,.975))]}
 pd.DataFrame(res).to_csv(O/'tables'/'phase21_cross_outcome_associations.csv',index=False,float_format='%.7g')
 # Original binomial GEE with target fixed effect, sensitivity to small-sample variance and individual clusters
 a=[]
 for ph,d in [('Pre',pre),('Post',post)]:
  for item in items:
   q=d[['user_id','learning_mode','Round',item+'_correct']].copy();q.columns=['participant','group','round','correct'];q['item']=item;q['phase']=ph;a.append(q)
 A=pd.concat(a,ignore_index=True)
 for col,cat in [('group',['predefined','llm']),('phase',['Pre','Post']),('round',[1,2,3]),('item',items)]:A[col]=pd.Categorical(A[col],categories=cat)
 form='correct ~ C(group, Sum)*C(phase, Sum)*C(round, Sum) + C(item)';term='C(group, Sum):C(phase, Sum):C(round, Sum)'
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',FutureWarning)
  robust=smf.gee(form,groups='participant',data=A,family=sm.families.Binomial(),cov_struct=sm.cov_struct.Exchangeable()).fit()
  bias=smf.gee(form,groups='participant',data=A,family=sm.families.Binomial(),cov_struct=sm.cov_struct.Exchangeable()).fit(cov_type='bias_reduced')
  rv=robust.wald_test_terms().table.loc[term];bv=bias.wald_test_terms().table.loc[term]
  pv=[];stat=[]
  for who in A.participant.unique():
   m=smf.gee(form,groups='participant',data=A[A.participant.ne(who)],family=sm.families.Binomial(),cov_struct=sm.cov_struct.Exchangeable()).fit()
   v=m.wald_test_terms().table.loc[term];pv.append(float(v.pvalue));stat.append(float(np.asarray(v.statistic).ravel()[0]))
 fit={'robust_wald_chi2':float(np.asarray(rv.statistic).ravel()[0]),'robust_wald_p':float(rv.pvalue),
      'bias_reduced_wald_chi2':float(np.asarray(bv.statistic).ravel()[0]),'bias_reduced_wald_p':float(bv.pvalue),
      'loo_n_fits':len(pv),'loo_p_min':min(pv),'loo_p_median':float(np.median(pv)),'loo_p_max':max(pv),
      'loo_fits_p_below_0_05':sum(p<.05 for p in pv),'loo_wald_chi2_min':min(stat),'loo_wald_chi2_max':max(stat),
      'notes':'One-participant-deletion refits are influence checks, not independent samples; robust Wald p values are exploratory and not multiplicity-adjusted.'}
 pd.DataFrame([{'model':'item_binomial_gee','variant':'participant_cluster_robust','wald_chi2':fit['robust_wald_chi2'],'p':fit['robust_wald_p'],'n_participants':46},
 {'model':'item_binomial_gee','variant':'bias_reduced_sandwich','wald_chi2':fit['bias_reduced_wald_chi2'],'p':fit['bias_reduced_wald_p'],'n_participants':46},
 {'model':'item_binomial_gee','variant':'leave_one_participant_out_lowest_wald','wald_chi2':min(stat),'p':max(pv),'n_participants':45},
 {'model':'item_binomial_gee','variant':'leave_one_participant_out_highest_wald','wald_chi2':max(stat),'p':min(pv),'n_participants':45}]).to_csv(O/'tables'/'phase21_gee_robustness.csv',index=False)
 # Practice-target completeness: preserve meaningful counts, only describe, never adjust intervention effects by missingness.
 R=pd.read_csv(D/'recordings.csv');ss=R[(R['round']==1)&(R.learning_mode=='predefined')].copy()
 ss['distinct_targets']=ss.learning_order.apply(lambda v:len(set(json.loads(v))))
 z=s[(s.group=='predefined')&(s['round']==1)].merge(ss[['user_id','distinct_targets']],left_on='participant',right_on='user_id',validate='one_to_one')
 desc=z.groupby(z['distinct_targets'].eq(20)).agg(n=('participant','count'),mean_pre=('pre','mean'),mean_post=('post','mean'),mean_gain=('gain','mean'),mean_game=('game_total','mean')).reset_index()
 desc['group_label']=desc['distinct_targets'].map({True:'20_distinct_recorded_targets',False:'14_to_18_distinct_recorded_targets'})
 desc=desc.drop(columns='distinct_targets');desc.to_csv(O/'tables'/'phase21_first_round_coverage_descriptives.csv',index=False,float_format='%.7g')
 datafile_names=['initial_assessment_data.csv','final_assessment_data.csv','recordings.csv','learning_session_data.csv','whack_a_mole_game.csv','all_users_initial_assessment.csv','all_users_final_assessment.csv','all_users_improvement.csv']
 report={'status':'COMPUTED_FROM_SUPPLIED_ANALYSIS_INPUTS','source_sha256':{name:hashfile(D/name) for name in datafile_names},'cross_outcome_association':evidence,'primary_gee_influence_check':fit,'coverage_subgroups':{r.group_label:dict(n=int(r.n),mean_pre=float(r.mean_pre),mean_post=float(r.mean_post),mean_gain=float(r.mean_gain),mean_game=float(r.mean_game)) for _,r in desc.iterrows()},'privacy':'No names, source participant IDs, or participant-level rows exported.'}
 (O/'audit'/'phase21_original_data_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print('SUCCESS, Cross-outcome:',evidence,'; GEE:',fit,'; practice:',report['coverage_subgroups'])
if __name__=='__main__':main()
