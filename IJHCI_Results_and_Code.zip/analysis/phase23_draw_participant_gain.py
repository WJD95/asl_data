#!/usr/bin/env python3
"""Regenerate Supplemental Figure S1 from authorized participant-level assessment CSVs.

Input data remain outside the publication package. The output contains only plotted
(non-identifying) values. This script never exports participant IDs or records.
Usage: python analysis/phase23_draw_participant_gain.py --data-dir /path/to/private/data
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from scipy.stats import t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

pa=argparse.ArgumentParser()
pa.add_argument('--data-dir',required=True)
args=pa.parse_args()
root=Path(__file__).resolve().parents[1]
D=Path(args.data_dir)
pre=pd.read_csv(D/'initial_assessment_data.csv')
post=pd.read_csv(D/'final_assessment_data.csv')
items=[x for x in pre.columns if x.endswith('_correct')]
assert len(items)==20
assert len(pre)==len(post)==138
keys=['user_id','Round','learning_mode']
for df in (pre,post):
 df['correct_total']=df[items].astype(int).sum(axis=1)
g=pre[keys+['correct_total']].merge(post[keys+['correct_total']],on=keys,suffixes=('_pre','_post'),validate='one_to_one')
assert len(g)==138 and g['user_id'].nunique()==46
g['change']=g.correct_total_post-g.correct_total_pre

TEAL='#187F89';ORANGE='#C37754';INK='#263648';GRID='#DCE4E9'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                     'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':GRID,
                     'xtick.color':INK,'ytick.color':INK,'figure.facecolor':'white','savefig.facecolor':'white'})
fig,ax=plt.subplots(figsize=(8.4,3.25))
rng=np.random.default_rng(20261117)
for k,(name,color,marker) in enumerate([('llm',TEAL,'o'),('predefined',ORANGE,'s')]):
 for rd in (1,2,3):
  vals=g.loc[(g.learning_mode==name)&(g.Round==rd),'change'].to_numpy(float)
  assert len(vals)==23
  x=rd+(-.16 if k==0 else .16)
  jitter=rng.uniform(-.063,.063,len(vals))
  ax.scatter(x+jitter,vals,s=23,marker=marker,color=color,alpha=.28,edgecolors=INK,linewidths=.2,zorder=2)
  mean=float(np.mean(vals));margin=t.ppf(.975,22)*np.std(vals,ddof=1)/np.sqrt(23)
  ax.plot([x,x],[mean-margin,mean+margin],lw=2.0,color=color,zorder=4)
  ax.plot([x-.045,x+.045],[mean-margin]*2,lw=1.5,color=color,zorder=4)
  ax.plot([x-.045,x+.045],[mean+margin]*2,lw=1.5,color=color,zorder=4)
  ax.scatter(x,mean,marker='D',s=66,color=color,edgecolor='white',lw=1.2,zorder=5)
ax.axhline(0,lw=1,color=INK,ls=(0,(3,3)),alpha=.7)
ax.set_xticks([1,2,3],['Round 1','Round 2','Round 3'])
ax.set_yticks([-4,0,4,8,12]);ax.set_ylim(-4.5,12.7)
ax.set_xlim(.57,3.4)
ax.grid(axis='y',color=GRID,lw=.8);ax.set_axisbelow(True)
ax.tick_params(length=0,pad=6)
ax.spines['left'].set_visible(False)
fig.subplots_adjust(left=.095,right=.985,top=.96,bottom=.13)
out=root/'figures'/'Fig4_participant_gain_distribution'
for ext in ['pdf','svg','png']:
 kwargs={'dpi':450} if ext=='png' else {}
 fig.savefig(out.with_suffix('.'+ext),bbox_inches='tight',pad_inches=.12,**kwargs)
plt.close(fig)
print('S1 regenerated: 46 unique participants × 3 rounds; no source data exported')
