#!/usr/bin/env python3
"""Redraw Figure 1 as editable vector geometry and text. No participant data required.
Output: figures/Fig1_measurement_pathways.pdf/.svg/.png. Figure caption belongs to main.tex.
"""
import argparse
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle
from matplotlib import rcParams
rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
INK='#22364B';MUTED='#52667B';TEAL='#14818C';BLUE='#587C9C';ORANGE='#B66F48';LINE='#D9E2E8'
FILL={'teal':'#E9F5F3','blue':'#ECF3F9','orange':'#FAF1EB'}

def box(ax,x,y,w,h,title,lines,color,fill,subtag=None):
 p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.3',linewidth=1.35,edgecolor=color,facecolor=fill)
 ax.add_patch(p)
 ax.text(x+2.2,y+h-3.1,title,size=13.8,weight='bold',color=INK,va='center')
 for j,t in enumerate(lines):
  ax.text(x+2.2,y+h-7.5-4.7*j,t,size=11.6,color=MUTED,va='center')
 if subtag:
  ax.text(x+w-2,y+2,subtag,size=9.6,color=color,va='center',ha='right')

def arrow(ax,x1,y,x2,c):
 ax.add_patch(FancyArrowPatch((x1,y),(x2,y),arrowstyle='-|>',mutation_scale=15,
                              linewidth=1.8,color=c,shrinkA=0,shrinkB=0))

fig,ax=plt.subplots(figsize=(11,5.55));ax.set_xlim(0,100);ax.set_ylim(12,100);ax.axis('off')
fig.patch.set_facecolor('white');fig.subplots_adjust(left=.03,right=.97,bottom=.025,top=.99)
# First panel
ax.text(2.0,95.4,'A',fontsize=19,color=TEAL,weight='bold',va='center')
ax.text(7,95.4,'INSTRUCTIONAL CONDITIONS',fontsize=16.8,color=INK,weight='bold',va='center')
ax.plot([2,98],[92.5,92.5],c=LINE,lw=1)
ax.text(3.2,88.0,'RECOGNITION-CONTINGENT PRACTICE',fontsize=11.2,color=TEAL,weight='bold',va='center')
box(ax,3,69,28,15.2,'Camera observation',['Learner presents a hand','configuration'],TEAL,FILL['teal'])
arrow(ax,31.5,76.6,35,TEAL)
box(ax,35.5,69,28.2,15.2,'Classifier decision',['Restricted target classes','Predicted configuration'],BLUE,FILL['blue'])
arrow(ax,64.2,76.6,67.7,TEAL)
box(ax,68.2,69,28.8,15.2,'Corrective feedback',['Prediction-dependent','finger-specific advice'],TEAL,FILL['teal'])
ax.text(3.2,64.4,'PREDEFINED VISUAL INSTRUCTION',fontsize=11.2,color=ORANGE,weight='bold',va='center')
box(ax,3,46,43.6,15,'Reference materials',['Target image and written guidance','Mnemonic aid; optional demonstration'],ORANGE,FILL['orange'])
arrow(ax,47.4,53.5,51.7,ORANGE)
box(ax,52.4,46,44.6,15,'Reference-led practice',['Learner can revisit target materials','No recognition-contingent correction'],ORANGE,FILL['orange'])
# Second panel
ax.text(2.0,37,'B',fontsize=19,color=TEAL,weight='bold',va='center')
ax.text(7,37,'THREE OUTCOME SOURCES  |  DIFFERENT MEANINGS',fontsize=16.8,color=INK,weight='bold',va='center')
ax.plot([2,98],[34,34],c=LINE,lw=1)
box(ax,3,14,29.9,16.4,'Image-choice assessment',['Correct selection; choice time','Scored apart from classifier'],TEAL,FILL['teal'])
box(ax,35,14,29.9,16.4,'Reinforcement game',['Recognizer-accepted events','Not expert-rated sign output'],BLUE,FILL['blue'])
box(ax,67,14,30,16.4,'Practice records',['Target coverage and duration','No linked feedback-uptake trace'],ORANGE,FILL['orange'])
for ext in ['pdf','svg','png']:
 p=Path(__file__).resolve().parents[1]/'figures'/f'Fig1_measurement_pathways.{ext}'
 fig.savefig(p,bbox_inches='tight',pad_inches=.04,dpi=500 if ext=='png' else None)
 print(p)
plt.close(fig)
