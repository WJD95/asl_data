"""Check recomputed outputs against the frozen aggregate data (numeric tolerance)."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--results-dir',type=Path,required=True);a=p.parse_args()
base=Path(__file__).resolve().parents[1]/'tables'
for f in sorted(base.glob('*.csv')):
 if f.name=='aggregate_headroom_descriptives.csv':
  x=pd.read_csv(a.results_dir/'assessment_descriptives.csv'); c=pd.read_csv(a.results_dir/'ceiling_summary.csv')
  for _,v in pd.read_csv(f).iterrows():
   sub=x[(x.group==v.group)&(x['round']==v['round'])];pre=sub[sub.phase=='Pre'].iloc[0];post=sub[sub.phase=='Post'].iloc[0]
   m=round(pre['mean']*int(v.n))/int(v.n); z=round(post['mean']*int(v.n))/int(v.n); h=20-m;g=z-m
   assert np.allclose([m,z,g,h,g/h],[v.pre_correct_mean,v.post_correct_mean,v.mean_observed_gain_items,v.available_headroom_items,v.ratio_of_mean_gain_to_mean_headroom],atol=1e-5)
   assert int(c[(c.group==v.group)&(c['round']==v['round'])&(c.phase=='Pre')].n_at_least_18.iloc[0])==v.pre_at_least_18_of_20
 else:
  x=pd.read_csv(f);y=pd.read_csv(a.results_dir/f.name);assert x.shape==y.shape and list(x)==list(y),f.name
  for col in x:
   if pd.api.types.is_numeric_dtype(x[col]):assert np.allclose(x[col],y[col],atol=1e-6,rtol=1e-6,equal_nan=True),(f.name,col)
   else:assert x[col].equals(y[col]),(f.name,col)
 print('PASS',f.name)
