#!/usr/bin/env python3
"""Vector Figure 6: observed pooled vs condition/round-centered associations with cluster-bootstrap CIs."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                 'axes.spines.top':False,'axes.spines.right':False,'font.size':11.8,'axes.labelsize':12,
                 'xtick.labelsize':10.4,'ytick.labelsize':11.5,'figure.facecolor':'white'})
D=Path(__file__).resolve().parents[1];table=pd.read_csv(D/'tables'/'phase21_cross_outcome_associations.csv')
colors={'pooled_ignoring_group_round':'#7E8694','within_condition_round':'#14818C'}
fig,axes=plt.subplots(1,2,figsize=(10.0,3.55),sharey=True)
for ax,var,title in zip(axes,['post','gain'],['Post-assessment score','Pre-to-post score change']):
 a=table[table.game_count_vs==var]
 for j,key in enumerate(['pooled_ignoring_group_round','within_condition_round']):
  x=a[a.analysis==key].iloc[0];pos=1-j;c=colors[key]
  ax.plot([x.cluster_bootstrap_low,x.cluster_bootstrap_high],[pos,pos],color=c,lw=3.0,zorder=2)
  ax.plot([x.cluster_bootstrap_low]*2,[pos-.065,pos+.065],color=c,lw=1.7)
  ax.plot([x.cluster_bootstrap_high]*2,[pos-.065,pos+.065],color=c,lw=1.7)
  ax.scatter(x.pearson_r,pos,s=112,color=c,edgecolor='white',linewidth=1.1,zorder=3)
  ax.text(.78,pos,f"{x.pearson_r:+.2f}  [{x.cluster_bootstrap_low:+.2f}, {x.cluster_bootstrap_high:+.2f}]",va='center',fontsize=10.0,color='#23374A')
 ax.axvline(0,color='#76899A',lw=1.1,linestyle=(0,(4,3)),zorder=1)
 ax.set_xlim(-.85,1.67);ax.set_ylim(-.55,1.55)
 ax.set_title(title,loc='left',fontsize=13.5,color='#24364A',weight='bold',pad=15)
 ax.set_xticks([-.75,-.5,-.25,0,.25,.5,.75]);ax.set_xticklabels(['−.75','−.50','−.25','0','.25','.50','.75'])
 ax.grid(axis='x',color='#E7ECF1',lw=.75);ax.set_axisbelow(True)
 ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#CBD3DC')
 ax.tick_params(axis='y',length=0)
axes[0].set_yticks([1,0],['Pooled across rounds','Within condition × round'])
axes[1].tick_params(axis='y',labelleft=False)
fig.subplots_adjust(left=.22,right=.985,bottom=.14,top=.84,wspace=.18)
for ext in ['pdf','svg','png']:
 kwargs={'dpi':500} if ext=='png' else {}
 fig.savefig(D/'figures'/f'Fig10_cross_outcome_association.{ext}',bbox_inches='tight',pad_inches=.1,**kwargs)
plt.close(fig)
