# Data dictionary — aggregate analysis results

CSV encoding: UTF-8, comma separated, header row. Numeric output precision is retained from the manuscript archive. All data derive from the same 46 participants. `llm` = recognition-contingent instructional condition; `predefined` = predefined visual instruction. `round` = 1, 2 or 3; `phase` = Pre or Post. `n` and `n_participants` count participants or the group-level records being summarized, not independent item observations. `Earlier 20` and `Additional 26` are two archived subsets of the same study, corresponding to Subsets A and B; they are not independent experiments. `digit`/`word` refer to the game target category.

| File | Unit / fields and interpretation |
|---|---|
| assessment_descriptives.csv | Condition × round × phase; mean correct choices (0–20), lo/hi 95% t intervals over participants, accuracy_pct = mean × 5. |
| gain_descriptives.csv | Condition × round; mean Post − Pre correct choices (items), lo/hi 95% t intervals. |
| latency_descriptives.csv | Condition × round × phase; mean participant-average image-choice response latency (seconds), lo/hi 95% t intervals. |
| games_descriptives.csv | Condition × round × type; mean recognizer-accepted count and lo/hi 95% t intervals. |
| practice_descriptives.csv | Condition × round; mean of participant-level averages of positively timed target entries (seconds), lo/hi 95% t intervals. |
| practice_coverage.csv | Subset × condition × round; n, mean logged event count (events_mean), mean number of distinct recorded targets (targets_mean), count of sessions with 20 distinct recorded targets (n_complete). |
| ceiling_summary.csv | Condition × round × phase; n_participants, mean_correct (0–20), number at 20, at least 18 and at least 16. |
| aggregate_headroom_descriptives.csv | Condition × round; pre/post means, mean gain in items, H = 20 − mean pre, Q = mean gain/H, number with pre score ≥18. Ratio of group means, not mean normalized participant gain. |
| accuracy_GEE_terms.csv | Item-level binomial logit GEE, exchangeable within participant, robust covariance, fixed target effects, condition × phase × round. |
| latency_GEE_terms.csv | Gaussian GEE on log response seconds, analogous factors and target adjustment. |
| games_GEE_terms.csv | Poisson log GEE, condition × round × type. No pre/post factor. |
| practice_GEE_terms.csv | Gaussian GEE of log participant-round mean positive practice duration, condition × round. |
| baseline_adjusted_GEE_terms.csv | Gaussian GEE of post score adjusted for pre score, condition × round. |
| baseline_adjusted_GEE_coefficients.csv | Term, coefficient estimate, robust standard error, lower/upper 95% Wald interval and p. Coefficients on the correct-choice count scale. |
| marginal_effect_contrasts.csv | Round-specific standardized pre/post gain contrast (recognition minus predefined): estimate_pp, low_pp, high_pp in percentage points, two-sided unadjusted p. |
| bootstrap_gain_change.csv | Round 3 minus Round 1 change in between-condition gain gap, est_items, low/high percentile 95% interval, B = 20,000. perm_p is an exploratory label-permutation value, not a valid design-based randomization test. |
| subgroup_sensitivity.csv | Accuracy three-way interaction under sample restrictions: subset, n, chi2, df, p. |
| phase21_cross_outcome_associations.csv | Game total versus post score or pre/post gain; raw pooled or within-condition/round-centered Pearson r, cluster-bootstrap bounds, 12,000 replicates, 46 participants and 138 participant-rounds. |
| phase21_gee_robustness.csv | Robust and bias-reduced sandwich estimates, extrema over 46 leave-one-participant-out refits. wald_chi2, p, n_participants. |
| phase21_first_round_coverage_descriptives.csv | Predefined group, Round 1; group_label = distinct recorded target count category; n, mean pre/post/gain (items), mean_game = sum of digit and word counts. |

For all GEE term files: `model` is an analysis label, `term` is the Patsy formula term (`C(..., Sum)` denotes sum coding), `chi2` is the robust Wald chi-square statistic, `df` its degrees of freedom, `p` the unadjusted upper-tail p value. Different model terms must not be treated as equivalent hypothesis tests. Repeated records within participants are clustered; confidence intervals and p values are exploratory and not multiplicity-adjusted.
